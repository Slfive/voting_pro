from django.contrib import messages
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.staticfiles import finders
from django.shortcuts import render, redirect
from django.http import HttpRequest, JsonResponse, HttpResponseForbidden, HttpResponse
from django.db import transaction
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.conf import settings
from django.conf.urls.static import static
from friendship.models import Friend, Follow, Block, FriendshipRequest
from .models import Profile
from .forms import UserLoginForm, UserRegisterForm, UserFormFilling, ProfileFormFilling
import os
import datetime



def login_view(request):
    context = {}
    next = request.GET.get('next')
    form = UserLoginForm(request.POST or None)
    context['form'] = form  
    context['register'] = 'Register'
    context['enter'] = 'Enter'

    if form.is_valid():
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(username = username, password = password)
        login(request, user)
        if user.is_active:
            context['loggined'] = True
        else: 
            context['loggined'] = False
        if next:
            return redirect(next)
        return redirect('/main/')
    
    if form.errors:
        context['error'] = 'Wrong username or password'

    return render(request, 'login_page.html', context)

def register_view(request):
    context = {}
    next = request.GET.get('next')
    form = UserRegisterForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        password = form.cleaned_data.get('password')
        user.set_password(password)
        user.save()
        new_user= authenticate(username=user.username, password=password)
        login(request, user)
        if user.is_active: 
            context['loggined'] = True
        if next:
            return redirect(next)
        print(form)
        return redirect('/main/')
    context['form'] = form
    context['errors'] = form.errors
    return render(request, 'register_page.html', context)

@login_required
def logout_view(request,):
    logout(request)
    return redirect('/login/' )

@login_required
def main_page(request, ):
    context = {}
    lang_pack = {
        'username' : 'Username',
        'fName' : 'Full name',
        'bDay' : 'Birthday',
        'location' : 'Location',
        'description' : 'Description',
        'email' : 'Email',
        'author' : 'Author',
        'header' : 'Headline',
    }
    
    context['lang_pack'] = lang_pack
    curr_user = User.objects.get(username = request.user.get_username())
    try:
        curr_prof = Profile.objects.get(user_id = curr_user.id) 
    except:
        curr_prof = Profile(
            user_id = curr_user.id,
        )
        curr_prof.save()

    #   Уведомления. Допилим потом, пока оставим так...
    if request.user.is_authenticated:
        Username = request.user
        context['loggined'] = True
        context['curr_logo'] = curr_prof.avatar
    else:
        return redirect('/login/')
        
    context['username'] = Username.get_username()
    return render(request, 'index.html', context=context)

@login_required
def profile_page(request, prof=''):
    context = {}
    Username = request.user 
    srch_user = User.objects.get(username = prof)
    try:
        srch_prof = Profile.objects.get(user_id = srch_user.id)    
    except:
        srch_prof = Profile(
            user_id = srch_user.id,
        )
        srch_prof.save()

    curr_user = User.objects.get(username = Username.get_username())
    curr_prof = Profile.objects.get(user_id = curr_user.id)    

    try:
        f = Friend.objects.get(to_user_id=srch_user, from_user_id=request.user)
        context['friends'] = True
    except:
        context['friends'] = False
    
    if not context['friends']:
        try:  
            fr = FriendshipRequest.objects.get(to_user_id = srch_user, from_user_id=request.id)      
            context['f_req'] = True
        except:
            context['f_req'] = False


    if request.user.is_authenticated:
        context['loggined'] = True
        context['profile_name'] = prof
        context['curr_logo'] = curr_prof.avatar
        context['username'] = Username.get_username()

        context['settings'] = False
        if context['username'] == context['profile_name']:
            context['settings'] = True
        
    lang_pack = {
        'username' : 'Username',
        'fName' : 'Full name',
        'bDay' : 'Birthday',
        'location' : 'Location',
        'description' : 'Description',
        'email' : 'Email',
        'author' : 'Author',
        'header' : 'Headline',
    }
    context['lang_pack'] = lang_pack
    context['profile'] = {
        'id' : srch_user.id,
        'full_name' : srch_user.first_name + ' ' + srch_user.last_name,
        'birthday' : srch_prof.birthday,
        'location' : srch_prof.location,
        'bio' : srch_prof.bio,
        'email' : srch_user.email,
        'userlogo' : srch_prof.avatar,
    }
    context['notifications'] = 5
   
    return render(request, 'profile_page.html',  context = context)

@login_required
def profile_filling(request, prof=''):
    if request.user.get_username() == prof:

        
        context = {}
        profile_form = ProfileFormFilling(request.POST or None , instance=request.user.profile)
        user_form_filling = UserFormFilling(request.POST or None, request.FILES or None,  instance=request.user)
            
        context['error'] = [profile_form.errors, user_form_filling.errors]

        curr_usr = User.objects.get(username=request.user.get_username())
        curr_prf = Profile.objects.get(user_id=curr_usr.id)

        if profile_form.is_valid() and user_form_filling.is_valid():
            if request.FILES:
                path = default_storage.save('avatars/{}'.format(request.FILES['avatar']), ContentFile(request.FILES['avatar'].read()))
                tmp_file = os.path.join(settings.MEDIA_ROOT, path)

                tmp_filling = profile_form.save(commit=False)
                tmp_filling.avatar = path
                tmp_filling.save()

            profile_form.save()
            user_form_filling.save()
            return redirect('/profile/{}'.format( prof))
        context['form'] = {
            'p' : profile_form,
            'u' : user_form_filling,
        }
        return render(request, 'settings.html', context=context)

    else: return HttpResponseForbidden()

def get_user(req, id):
    cur_user = User.objects.get(id=id)
    cur_prof = Profile.objects.get(user_id=cur_user.id)

    resp = {
        'id' : id,
        'username' : cur_user.username,
        'first_name': cur_user.first_name,
        'last_name' : cur_user.last_name,
        'avatar' : cur_prof.avatar
    }

    return JsonResponse(resp, safe=False)

def get_requests(request, user=''):
    curr_user = User.objects.get(pk=user)
    unformatted_data = FriendshipRequest.objects.filter(to_user=curr_user.id)
    resp=[]
    i = 0
    for each in unformatted_data:
        temp_user = User.objects.get(pk=each.from_user_id)
        resp += [{
            'id' : i,
            'author' : {
                'id' : temp_user.id,
                'username' : temp_user.username,
                'first_name': temp_user.first_name,
                'last_name' : temp_user.last_name,
                'avatar' : '/media/' + str(Profile.objects.get(user_id=each.from_user_id).avatar)
            },
            'mess' : each.message,
            'datetime': each.created.strftime("%H:%M %Y-%m-%d")
        }]
        i -=-1
    return JsonResponse(resp, safe=False)

@login_required
def create_req(request, user):
    other_user = User.objects.get(username=user)
    try:
        Friend.objects.add_friend(
        request.user,
        other_user,
        message = 'I wanna add you bruh...',
    )
    except:
        pass
    return HttpResponse('<script type="text/javascript">window.close()</script>')

@login_required
def accept_friend(request, pk,):
    friend_request =  FriendshipRequest.objects.get(to_user_id=request.user, from_user_id=pk)
    friend_request.accept()
    return HttpResponse('<script type="text/javascript">window.close()</script>')


@login_required
def remove_friend(request, pk):
    other_user = User.objects.get(pk=pk)
    Friend.objects.remove_friend(request.user, other_user)
    return HttpResponse('<script type="text/javascript">window.close()</script>')

@login_required
def block_user(request, pk):
    other_user = User.objects.get(pk=pk)
    Block.objects.add_block(request.user, other_user)
    return HttpResponse('<script type="text/javascript">window.close()</script>')

@login_required
def remove_block(request, pk):
    other_user = User.objects.get(pk=pk)
    Block.objects.remove_block(request.user, other_user)
    return HttpResponse('<script type="text/javascript">window.close()</script>')

def empty_url(req):
    return redirect('/main/')

@login_required
def notificate(request):
    context = {}
    context['username'] = request.user.get_username()
    context['loggined'] = True
    context['curr_logo'] = Profile.objects.get(user_id=request.user).avatar
    return render(request, 'notifications.html', context)


def get_friends(request, pk):
    unformatted_data = Friend.objects.filter(from_user_id=pk)
    resp = []
    for each in unformatted_data:
        u_tmp = User.objects.get(id=each.to_user_id)
        p_tmp = Profile.objects.get(user_id=u_tmp.id)
        resp += [{
            'id'        : u_tmp.id,
            'username'  : u_tmp.username,
            'first_name': u_tmp.first_name,
            'last_name' : u_tmp.last_name,
            'avatar'    : '/media/' + str(p_tmp.avatar),
        }]

    return JsonResponse(resp, safe=False)

def show_friends(request):
    context = {'loggined' : True}

    context['curr_logo'] = Profile.objects.get(user_id=request.user).avatar

    return render(request, 'friendlist.html', context)

def any_news(request, pk):
    resp = False
    try: 
        tmp = 0
        r = FriendshipRequest.objects.filter(to_user_id=pk)
        
        for each in r:
            tmp += 1

        if tmp:
            resp = True
        else: 
            resp = False
    except:
        resp = False
    print(resp)
    return JsonResponse(resp, safe=False)