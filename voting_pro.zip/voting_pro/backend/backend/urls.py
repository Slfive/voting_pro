from django.contrib import admin
from django.urls import path
from accounts import views
from card_holder import views as cv
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
from django.conf import settings
from django.contrib.auth import views as auth_views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.login_view),
    path('register/', views.register_view),
    path('logout/', views.logout_view),
    path('main/', views.main_page),
    path('notifications/', views.notificate),
    path('friends/', views.show_friends),
    path('accounts/login/', views.login_view),

    path('profile/<str:prof>/', views.profile_page),
    path('profile/<str:prof>/settings/', views.profile_filling),

    path('api/cards/get/<str:Filter>', cv.get),
    path('api/cards/post/', cv.post),
    path('api/cards/<int:card_id>/<int:answer_id>', cv.voting),
    path('api/cardrateup/<int:pk>', cv.rateup),
    path('api/cardratedown/<int:pk>', cv.ratedn),


    path('api/friends/req/<str:user>', views.create_req),
    path('api/friends/getreq/<int:user>', views.get_requests),
    path('api/friends/add/<int:pk>', views.accept_friend),
    path('api/friends/del/<int:pk>', views.remove_friend),
    path('api/friends/blk/<int:pk>', views.block_user),
    path('api/friends/ublk/<int:pk>', views.remove_block),
    path('api/friends/list/<int:pk>', views.get_friends),
    path('api/friends/nots/<int:pk>', views.any_news),

    path('reset_password/', auth_views.PasswordResetView.as_view(), name = 'reset_password'),
    path('reset_password_done/', auth_views.PasswordResetDoneView.as_view(), name = 'password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset_password_cmpt/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),

    path('', views.empty_url),
]

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)