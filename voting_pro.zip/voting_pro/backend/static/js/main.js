new Vue({
    el: '#cardholder',
    delimiters: ['[[', ']]'],
    data: {
        cards: [],
        last_card: undefined,
        showCardContent: [],
        url: [],
        offset: window.pageYOffset,
    },
    methods: {
        ChangePage(someID, val){
            const children = document.querySelectorAll('.someID')
            
            for (const each in children){
                if(children[each].value == someID){
                    const parent = children[each].parentElement
                    if (val == 1){
                        parent.querySelector('.page-1').classList.remove('unshowin')
                        parent.querySelector('.page-2').classList.add('unshowin')
                        parent.querySelector('.page-3').classList.add('unshowin')
                    }
                    if (val == 2){
                        parent.querySelector('.page-1').classList.add('unshowin')
                        parent.querySelector('.page-2').classList.remove('unshowin')
                        parent.querySelector('.page-3').classList.add('unshowin')
                    }
                    if (val == 3){
                        parent.querySelector('.page-1').classList.add('unshowin')
                        parent.querySelector('.page-2').classList.add('unshowin')
                        parent.querySelector('.page-3').classList.remove('unshowin')
                    }
                }
            }

            
        },
        renderAnser(obj){
            let u_data = obj.split('|')
            let r_data = []
            for (let e in u_data){
                r_data[e] = {
                    'id' : e,
                    'value' : u_data[e]
                }
            }
            return r_data
        },
        renderStats(obj1, obj2){
            let u_data1 = obj1.split('|')
            let u_data2 = obj2.split('|')
            let r_data = []
            for (let e in u_data1){
                r_data[e] = {
                    'id' : e,
                    'value' : u_data1[e],
                    'name' : u_data2[e]
                }
            }
            return r_data
        },
        openCard(someId){
            const children = document.querySelectorAll('.someID')
            this.active_card_id = someId

            for (const each in children){
                if(children[each].value == someId){
                    this.showCardContent = this.cards[each]
                    
                    const parent = children[each].parentElement
                    
                    children[each].parentElement.classList.toggle('active-card')
                    parent.querySelector('.page-1').classList.add('unshowin')
                    parent.querySelector('.page-2').classList.remove('unshowin')
                    parent.querySelector('.page-3').classList.add('unshowin')

                }
            }
        },
        collapseCard(someId){
            const children = document.querySelectorAll('.someID')
            for (const each in children){
                if(children[each].value == someId){
                    const parent = children[each].parentElement
                    parent.classList.toggle('active-card')

                }
            }
        },
        vote(cardId, answerId){
            axios.post(`/api/cards/${cardId}/${answerId}`).then(this.getCards())
            this.last_card = cardId
            this.collapseCard(cardId)
        },
        rate(cardId, val){
            val > 0 ? axios.post(`/api/cardrateup/${cardId}`).then(this.getCards()) : axios.post(`/api/cardratedown/${cardId}`).then(this.getCards())
        },
        getCards(){
            const end = parseInt(String(window.location.href).length)
            this.url = String(window.location.href).substr(22, end).split('/')
    
            if(this.url[0] == 'main'){
                axios.get('/api/cards/get/ALL').then( res => {
                    this.cards = res.data.sort( (a, b )=> b.rate - a.rate > 0 ? 1 : 0 )
                    console.log(res.data)
                } ).catch( res => {
                    console.log('rrr', res)
                } )
            }else if (this.url[0] == 'profile'){
                axios.get(`/api/cards/get/U${this.url[1]}`).then( res => {
                    this.cards = res.data.sort( (a, b )=> b.id - a.id > 0 ? 1 : 0 )
                    console.log(res.data)
    
                } ).catch( res => {
                    console.log('rrr', res)
                } )
            }
        }
    },
    mounted(){
        this.getCards()
    },
})