new Vue({
    el : '#friendholder',
    delimiters : ['[[', ']]'],
    data : {
        const_users : [],
        users : [],
        searchin : ''
    },
    methods : {
        getUsers(){
            axios.get(`/api/friends/list/${document.querySelector('#userID').value}`
            ).then( res => {
                this.const_users = res.data
                this.users = this.const_users
            } ).catch( err => {
                console.log('rrr', err)
            } )
        },
        gotoUser(username){
            window.parent.location.href = `/profile/${username}`
        },
        del(pk){
            console.log(pk)
            window.open(`/api/friends/del/${pk}`, '_blank')
            setTimeout(()=>this.getUsers(), 200)
        },
        block(pk){
            console.log(pk)
            window.open(`/api/friends/blk/${pk}`, '_blank')
            setTimeout(()=>this.getUsers(), 200)
        }
    },
    mounted(){
        const end = parseInt(String(window.location.href).length)
        const url = String(window.location.href).substr(22, end).split('/')

        if(url[0] === 'friends'){
            this.getUsers()
        }
    },
    watch:{
        searchin(){
            if(this.searchin.replace(/\s/g, "") != ""){
                console.log('smth happening')
                this.users = this.users.filter(user => {
                    return user.username.toLowerCase().includes(this.searchin.toLowerCase())
                } )
            } else {
                this.users = this.const_users
            }
        }
    }
})