new Vue({
    el : '#notificator',
    delimiters : ['[[', ']]'],
    data : {
        notes : []
    },
    methods : {
        getNotes(){
            axios.get(`/api/friends/getreq/${document.querySelector('#userID').value}`
            ).then( res => {
                this.notes = res.data
            } ).catch( err => {
                console.log('rrr', err)
            } )
        },
        add(id){
            const pk = this.notes[id].author.id
            window.open(`/api/friends/add/${pk}`, '_blank')
            this.getNotes()
        },
        block(id){
            window.open('/api/friends/blk/<int:pk>', '_blank')
            this.getNotes()
        },
        gotoUser(username){
            window.parent.location.href = `/profile/${username}`
        },
    },
    mounted(){
        const end = parseInt(String(window.location.href).length)
        const url = String(window.location.href).substr(22, end).split('/')
        if(url[0] === 'notifications'){
            this.getNotes()
            setInterval( () => {
                this.getNotes()
            }, 1000)
        }
    }
})