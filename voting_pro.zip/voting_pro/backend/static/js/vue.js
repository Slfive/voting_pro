new Vue({
    el: '#app',
    delimiters: ['[[', ']]'],
    data: {
        answerState : false,
        showModalCreate : false,
        showAnswers: [],
        tmpAnswer : '',
        headline : '',
        description : '',
        compiledAnswers : '',
        nots : false,
    },
    methods: {
        newAnswer(){
            if (this.tmpAnswer.replace(/\s/g,"") != ""){
                if(!this.compiledAnswers) this.compiledAnswers += this.tmpAnswer
                else this.compiledAnswers += '|' + this.tmpAnswer
                
                this.tmpAnswer = ''
                this.showAnswers = this.compiledAnswers.split('|')
                this.answerState= false
            }
        },
        addCard(){
            this.showModalCreate = true
        },
        collapseAll(){
            this.showModalCreate = false
        },
        getNots(){
            const id = document.querySelector('#userID').value 
            axios.get(`/api/friends/nots/${id}`).then( res => {
                this.nots = res.data
            } )
        }
    },
    computed: {
        modal(){
            let tmp = ''
            this.showModalCreate ? tmp = '' : tmp = 'owerflow: hidden;'
            return tmp
        }
    },
    mounted(){
        this.getNots()
        setInterval( () => this.getNots(), 10000 )
    }
})