from django.apps import AppConfig


class CardHolderConfig(AppConfig):
    name = 'card_holder'
