from django.db import models
from django.contrib.auth.models import User

class Card(models.Model):
    headline = models.CharField(max_length=128)
    description = models.CharField(max_length=255)
    answers = models.TextField()   # варианты ответов 
    ans_stats = models.TextField(blank=True) # кол-во ответов 
    rating = models.IntegerField(blank=True, default=0)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self):
        return self.headline