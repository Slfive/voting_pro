from django import forms
from .models import Card


class CardFilling(forms.ModelForm):
    class Meta:
        model = Card
        fields = [
            'author',
            'headline',
            'description',
            'answers',            
        ]
