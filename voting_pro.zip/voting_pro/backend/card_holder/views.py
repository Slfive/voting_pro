from .models import                     Card
from django.contrib.auth.models import  User
from .forms import                      CardFilling
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponseNotFound, HttpResponseForbidden, HttpResponse, HttpRequest
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt


def get(request, Filter=''):
    resp = []
    if request.method == 'GET':
        if Filter == 'ALL':
            unformatted_data = Card.objects.all()
            for each in unformatted_data:
                resp += [{
                    'id' : each.id,
                    'author' : each.author.username,
                    'description' : each.description,
                    'headline' : each.headline, 
                    'answers' : each.answers,
                    'rating' : each.rating,
                    'ans_stats' : each.ans_stats,
                }]
        if Filter[0] == 'U':
            try:
                curr_usr = User.objects.get(username=Filter[1:])
            except User.DoesNotExist:                
                return HttpResponseNotFound(content='<h1 class = "centered-shit">NOT FOUND</h1>')

            unformatted_data = Card.objects.all()
            for each in unformatted_data:
                if each.author == curr_usr:
                    resp += [{
                        'id' : each.id,
                        'author' : curr_usr.username,
                        'description' : each.description,
                        'headline' : each.headline, 
                        'answers' : each.answers,
                        'rating' : each.rating,
                        'ans_stats' : each.ans_stats,
                    }]
        return JsonResponse(resp, safe=False)
    else: 
        return HttpResponseForbidden()

def post(request): #/api/cards/post/
    cur_usr = User.objects.get(username=request.user.get_username())
    
    if request.method == 'POST':
        cur_h = request.POST['headline']
        cur_d = request.POST['description']
        cur_a = request.POST['answers']
        if cur_a and cur_d and cur_h:
            c = Card(
                headline=       cur_h,
                description=    cur_d,
                answers=        cur_a,
                ans_stats='NO_STATS',
                rating=0,
                author=cur_usr
            )
            c.save()

            return redirect('/')
            return HttpResponse(status=201)
        return HttpResponse(status=400)
        
    else:
        return redirect('/')

@csrf_exempt
def voting(request, card_id, answer_id):
    question_card = Card.objects.get(pk=card_id)
    answers = question_card.ans_stats
    if request.method == 'POST':
        answers_amount = len(question_card.answers.split('|'))
        print(answers_amount)

        if answers == 'NO_STATS':
            answers = []
            for i in range(0, answers_amount):
                answers.append('0')

            answers[answer_id] = str( int(answers[answer_id]) + 1 )
        else:
            answers = answers.split('|')
            answers[answer_id] = str( int(answers[answer_id])+ 1 )
        
        print(answers)
        question_card.ans_stats = '|'.join(answers)
        question_card.save()
        print('======ANSWER=REGISTERED======')
        return HttpResponse(status=201)
    else: 
        return HttpResponseForbidden('<h1> FORBIDDEN mazafaka</h1>')

def res(request, obj):
    votedata = []

    user_question = Card.objects.get(id=obj)
    votes = user_question.choice_set.all()
    for i in votes:
        votedata.append({i.choice:i.votes})

    return JsonResponse(votedata, safe=False)

@csrf_exempt
def rateup(request, pk):
    question_card = Card.objects.get(pk=pk)
    if request.method == 'POST':
        print(request.POST)
        question_card.rating = str(int(question_card.rating) + 1)
        question_card.save()
        return HttpResponse(status=200)
    else: return HttpResponseForbidden()

@csrf_exempt
def ratedn(request, pk):
    question_card = Card.objects.get(pk=pk)
    if request.method == 'POST':
        print(request.POST)
        question_card.rating = str(int(question_card.rating) - 1)
        question_card.save()
        return HttpResponse(status=200)
    else: return HttpResponseForbidden()